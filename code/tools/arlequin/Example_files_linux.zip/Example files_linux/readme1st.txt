						==========================						
						= Arlequin example files =
						==========================

You will find several example of project files in different sub-directories
covering most of what can be done with Arlequin.

All project files (extension *.ARP) have associated settings files (*.ARS), 
with predefined tasks to perform and customized options.
For these settings to be associated with the project files, you will need 
first to check the menu :

	Options | Use Associated Settings

Once this menu is checked, the settings file associated with each project 
will be automatically loaded at the same time you open a project with 
Arlequin.

You are welcome to play with these files and to change some options in order 
to see their effects on the results.

------------
Arlequin development team
July 2005

